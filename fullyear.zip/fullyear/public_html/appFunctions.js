/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



var prototype = (function () {
    "use strict";
    
        var oldCanvas = '<canvas width="' + 320 + '" height="' + 320
            + '" id="' + 'canvas_1">' +
            'initialisation!' +
            '</canvas>';

    var pub = {};


    pub.protoInitialise = function () {

 console.log("hello") ; 
 
 $.get("emulator.js", function () {
            resetCanvas(oldCanvas);


        });
    };


    
    return pub;
}());
